# Name of the project : MARIO GAME PARTY

* author 1: Oumeima EL GHARBI
* author 2: Achraf AZALMAD

L1 SESI Maths/Info ; group 11
The 07/05/2019


	**/ How to launch the program :
- Run the script called : partyGame_azalmad_elgharbi_FINAL.py
- Let the Turtle graphics window on one side of the screen
- Read and follow the instructions given by the shell




	**/ Work progression from the 1st to final rendering on moodle :

	## Week of March 25th to 3rd April

### Objectives : Conceptualize the game and choose the data structure to create the game

With ### FIRST RENDERING
*/ Done on the 01/04/2019 and on the 02/04/2019

I created the board (a list of numbers), and the players with dictionaries.
I put all the players on the same square at the start of the game.

I put the star at a random position, and I used print to create interaction between the program and the players.

I used the fonctions from the interface.zip archive to create the board and to move the characters.

I created an input to ask the players for the number of rounds they want to play.
I treated ValueError problems (for example converting a float into an integer), since such problems stop the game.

I also made the game in the section '#4/ Tour de jeu' with a loop, 
a round is one round of the loop for and each player plays once for one round.

The players are asked of they want to use objects (but since we didn't create the objects yet, it doesn't have an effect on the game yet).

Then, we move the character of the player that is playing.

Then, we give an information concerning the color of the square where the character arrives.

I also did the part where the player is asked if he wants to buy the star if he has enough coins


- We imagined the objects (banana, mushroom, golden mushroom, steel glove), but we need to improve that part.

I also wrote the code for the ranks at the end of the game, to determine the winner or winners.

I created a .csv file to record the number of coins and stars... of the players.



Conclusion : We can play the game, it works but it is not fun yet.


	## Weeks from April 1st to 11th April
### Objectives :

With ### SECOND RENDERING
*/ Done on the 11/04/2019

I deleted all the part about the objects that wasn't working and created it again from the start.

We have four objects,
I organized "the effects" that the use of an object has on the game.
So now, the objects are taken into account in the game.
The game asks the players if they want to use their objects, and the game checks if they can use them (for example, you can't steal a star from a player who has no stars.)

I improved the section when a character arrives on a blue square.
Now, there is no more problems when a character wins an object and uses it.


I also added in the dictionary of each players a key 'dice' and a key 'distance'. The key 'dice' is useful when a player uses an object that changes the dice ;
The key 'distance' is used to keep track of the distance that each character 'walked'. I added it in the .csv file.


Conclusion : Now, we need to improve the game to make it more fun ; 
and we need to improve the csv file to record the ranks and scores.



	## Weeks from April 11th April to 1st of May
### Objectives : ... + transform the big bloc of code that we wrote into functions !!

With ###THIRD RENDERING
*/ Done on the 11/04/2019

- Condition about the pseudos : two players can't have the same pseudos !!


*/ Done on the 20/04/19 : when the game is played by one player only and that player has objects. When we just have one player, if the player gets on a blue circle, the players always gets the object 'Golden Mushroom', because, now, this is the only object that doesn't need an opponent.

*/ Done for the 23/04/2019 :

For the improvements we did multiple procedures to make the game more fun.
- The first one is about the dices thrown by the players in a game so we created a variable to save all the numbers of dices displayed for each player in every round and from that we give an extra 5 coins 
for the one or ones with the biggest score. 

- Then we come to the end of the game so for that we created two variales one is a list of the number of objects of each players and by that we give the one with the biggest number an extra star, then we created the second variable wich is a list of each player's distance an from that we give the one with the bigest number an extra 10 coins and that can change the statistics of the game to give chance to other players to win.

*/ 24/04/2019 : There is no functions in the code except for the interface given by the teacher... Need to change the code into functions !


*/ 29/04/2019 : Transformation of all the code into functions !!
-

*/ 30/04/2019 : 

- Removing the interface code from the game code
- Completed and finished the docstring + UC of the functions
- Modification of the prints for the functions end_round_dice ; biggest_num_obj ; long_distance
- Tests when running the program



	## Week of 2nd May to 6th May

### Objectives : 

Check that all possible problems were treated (like exceptions with 'Try' 'except')

With ###FINAL RENDERING

*/ Done for the 07/05/2019 : slideshow

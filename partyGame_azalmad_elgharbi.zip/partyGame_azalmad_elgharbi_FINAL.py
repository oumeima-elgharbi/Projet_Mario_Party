"""
PROJECT AP1 : MARIO PARTY GAME
Authors : Oumeima EL GHARBI, Achraf AZALMAD
Teacher : Ammar HASAN
SESI Math/Info Group 11

Last Update : 07/05/2019
"""

from random import randint, randrange
from interface import *  # interface given by the teacher on the website for the project


# Date : 01/04/2019

    # I/ Definition of the data structure for the game

# 1/ The boardgame == plateau

plateau = [2,1,1,1,2,1,1,3,2,1,2,3,2,1,3,2,1,1,3,1,2,1,3,2]
# random boardgame => N

# 2/ The players == Les joueurs
joueur = dict()
players = list()
price_star = 5
dice = 0
ind = randint(1, (len(plateau) - 1)) # puts the star at a random position on the board


def players_in_game(nb_of_players, list_players):
    """
This procedure creates the players dictionaries by using the input method*

:param nb_of_players: (int) the number of players
:param list_players: (list) a list that we can add our players to
:return: None
:effet de bord: Creates a list of players

:CU: nb_players >= 1

"""
    player = {'pseudo': '', 'position': 0, 'coins': 5, 'stars': 0, 'objects': [], 'dice':0, 'distance':0}
    list_pseudo = []
    
    for i in range(nb_of_players):
        name = input('\nPlease enter your pseudo : ')
        
        while (name in list_pseudo): # means two players have the same pseudo !!
            print('\nPlease enter another pseudo, this one is already taken...')
            name = input('\nPlease enter your pseudo : ')
            
        list_pseudo.append(name)
        j = player.copy() # else le même dictionnaire qui sera modifié !!!
        j['pseudo'] = name
        j['objects'] = [] # USEFUL else everyone gets the same object AT THE SAME TIME // weird mdrr
        list_players.append(j)


def change_position(the_player):
    """
The Procedure changes the position of the player given in the parameter in the board

:param the_player: (dict) the dictionary of a player
:return: None
:effet de bord: moves a player accordinf to the number displayed on the dice

:CU:  player must contain the key 'dice', 'position', 'distance'.

"""
    
        
    input('\nPress the enter buttom  on your keyboard to roll the dice !') # mieux pas besoin result
    dice = randint(1, 6)
    print('\nThe dice displays :', dice)
        
    de = the_player['dice'] + dice # if 'Golden Mushroom' object used : +3
    print('\nYour character will be moved by :', de)

    the_player['distance'] += de # WE KEEP TRACK OF THE TOTAL DISTANCE !!!

    the_player['position'] = (the_player['position'] + de) % len(plateau) # ok
    bouge_perso(players, plateau) # we move each player now for a round !!
        # only our player will have its position changed !

        # dice = 0 now
    the_player['dice'] = 0
    dices.append(dice) # The list of each players dice number

    
    
def events(the_player):
    """
This procedure gives you the prizes of each color in the board relative to your position

:param the_player: (dict) a dictionary of a player
:return: None

:CU: the_player must contain the keys 'position', 'coins', 'objects'
AND  'list_objects' must be a list that contains 1 or 4 objects according to the number of players ; it is a global variable
"""
    nb_color = plateau[the_player['position']] # we get the color thanks to the board game

    if nb_color == 1: # GREEN
        the_player['coins'] += 3
        print('\nLucky you ! You got on a green square ! You earned 3 coins !')
        print('Now you have', the_player['coins'], 'coins !')
            
    elif nb_color == 2: # RED
        the_player['coins'] -= 3
        print('\nUnfortunately you got on a red square... You just lost 3 coins...')
        print('Now you have', the_player['coins'], 'coins !')

    else: # BLUE
        print('\nLucky you ! You got on a blue square ! You won a new object !')

        if nb_players != 1:
            nb_object = randint(0,3) 
                
        else: # if just one player !!
            nb_object = randint(0,0) # until new objects == > just One object can be used that doesn't need an opponent !!
               
        new_obj = list_objects[nb_object] # we choose randomly an object from our list
        print('\nYou got this new object', new_obj)

        the_player['objects'].append(new_obj) # it's a list, we add a new object // 'list_objects[nb_objet]' is a string // OK
        print('\nThis is your new inventory of objects that can be used in the next round :', the_player['objects'])


ind = randint(1, (len(plateau) - 1)) # puts the star at a random position on the board ************************** ???????????????????????????????


def star_event(the_player, star_index): # ***
    """
this procedure defines the star event such that if a player lands on the star position, he will be asked if he would buy it (the star) or not

:param the_player: (dict) a player's dictionary
:param star_index: (int) a given position of the star

:CU : 0 <= star_index < len(plateau) ; 'plateau' being a list of integers that represents the boardgame
AND the global variable 'plateau' must be defined outside of this fonction !
AND the_player must be a dictionary that contains the keys 'position', 'coins', 'stars'

"""
    if the_player['position'] == star_index and the_player['coins'] >= price_star: # the player meets the star and has enough coins to buy it
        reponse = ''
        while not(reponse == 'yes' or reponse == 'no'):
            reponse = input('\nDo you want to buy this star ? It will cost you ' + str(price_star) + ' coins ' + '\nKnowing that you have now : ' + str(the_player['coins']) + ' coins' + '\nPlease answer by "yes" or "no" : ')

        if reponse == 'yes':
            the_player['stars'] += 1
            the_player['coins'] -= price_star
            print('\nNow you have', the_player['stars'], 'stars ! But since you payed the stars, you have', the_player['coins'], 'coins left !')

                # we position a new star
            star_index = randint(1, (len(plateau) - 1)) # puts the star at a random position on the board
            place_etoile(star_index, plateau) # initially the star is not on the first square like all the players

    elif the_player['position'] == star_index:
        print("You can't buy this star, you have only", the_player['coins'], 'coins !')



    
def gameplay(nb_of_players, list_players): 
    """
This procedure concludes the game and it regroups all the procedure defined above and also it contains an important part of the game which is the objects
This procedure represents a round of the game when ONE player is playing :

First we ask the player if he wants to use an object if his inventory is not empty
Secondly, the program makes events according to the answer of the player for the use of an objects
Thirdly, the program plays the events like the change of position of the player, ... and asks the player of he wants to buy a star

:param nb_of_players: (int) the number of players
:param list_player: (list) list of dictionaries
:return: None
:effet de bord: 

:CU: nb_players >= 1 AND list_players must contain dictionaries that contain the keys 'pseudo', 'stars', 'objects', 'coins', 'dice' ????
AND the functions   change_position(joueur) + events(joueur) + star_event(joueur, ind) must be well defined !!

"""    
    # A player is playing :
    joueur = players[nb_player] # we take from the list the player that is playing now
    print('\n', joueur['pseudo'], 'is playing')
        
        # 1/ Use of objects :
        
    if joueur['objects'] != []: # if the list of objects is not empty // And if the number of players is ONE ==> only one object can be used
        answer = ''
        while not(answer == 'yes' or answer == 'no'):
            answer = input('\nDo you want to use one of your objects ?\nPlease answer by "yes" or "no" : ')
                
        if answer == 'yes':
            print('\nThese are all the objects that you possess :', joueur['objects'])
            print('\nA little remainder of the usefulness of the objects that you can win :', '\n- Banana : Steals 5 coins from an opponent', '\n- Steel Glove : makes you steal a star from an opponent', '\n- Golden Mushroom : adds 3 to your own dice', '\n- Mushroom : removes 3 to the dice of an opponent')

                # Date : 11/04/2019
                
            obj_used = ''
            while not(obj_used in joueur['objects']):
                obj_used = input('\nEnter the object you want to use from the list of objects that you possess : ')

                    # at the end of the while, we get the object in the list :
                
               
            if obj_used == 'Golden Mushroom': # NO OPPONENT NEEDED ! 
                joueur['dice'] = 3
                joueur['objects'].remove('Golden Mushroom') # we remove the object that was used
                print('\nAfter using the object Golden Mushroom, you have now added 3 to your dice for this round.') # better if ask to add 3 or not after throwing the dice ??
                                        
            else:
                list_opponents = [players[i]['pseudo'] for i in range(nb_players) if players[i]['pseudo'] != joueur['pseudo']]

                opponent = ''
                while not(opponent in list_opponents):
                    print('This is the list of th pseudo of your opponents :', list_opponents)
                    opponent = input('\nPlease enter the pseudo of your opponent ! : ')

                    # we get the dictionary of the opponent !

                for j in range(nb_players):
                    if players[j]['pseudo'] == opponent:
                        adversaire = players[j] # we got the dictionary of the opponent !!
                        break # end of the loop, since we got the informations that we needed
                    
                if obj_used == 'Mushroom': # we remove 
                    adversaire['dice'] -= 3
                    joueur['objects'].remove('Mushroom') # we remove the object that was used

                    print('\nAfter using the object Mushroom, you have now removed 3 to the dice of', opponent, 'for the next round.')
           
                elif obj_used == 'Banana': # we steal

                        # IF THE OPPONENT HAS 0 COINS !!
                    if adversaire['coins'] == 0:
                        print('Sorry... but this opponent has 0 coins for now... You can keep your object and use it later on in the game...')
                            
                    else:
                        adversaire['coins'] -= 5
                        joueur['coins'] += 5
                        joueur['objects'].remove('Banana') # we remove the object that was used

                        print('After using the object Banana, you have now', joueur['coins'], 'coins.')
                        print('And,', opponent, 'now has', adversaire['coins'], 'coins.')
           
                elif obj_used == 'Steel Glove': #
                        # IF THE OPPONENT HAS 0 STARS !!
                    if adversaire['stars'] == 0:
                        print('Sorry... but this opponent has 0 stars for now... You can keep your object and use it later on in the game...')
                            
                    else:
                        adversaire['stars'] -= 1
                        joueur['stars'] += 1
                        joueur['objects'].remove('Steel Glove') # we remove the object that was used

                        print('After using the object Steel Glove, you have now', joueur['stars'], 'stars.')
                        print('And,', opponent, 'now has', adversaire['stars'], 'stars.')
    
    change_position(joueur)
    events(joueur)
    star_event(joueur, ind)
    



def end_round_dice(nb_of_players, list_players, liste): # ****
    """
Gives at the end of each round the player who got the biggest score an extra 5 coins

:param nb_of_players: (int) the number of players
:param list_player: (list) list of dictionaries
:param liste: (list) the list of the dices thrown by each player in a round
:return: None
:effet de bord: Adds 5 coins to the dictionary of the player (or players) who got the biggest score for the dice roll !

:CU: list_players must contain dictionaries that contain the key 'pseudo', 'coins' AND nb_players >= 1
"""
    if liste != [] and nb_of_players != 1: # the execution of the code for the 'Amelioration' such that the one with the biggest score is the winner
        if len(set(liste)) == nb_of_players:
            ind_max = liste.index(max(liste))
            print('\nThe player who got the biggest score is : ', list_players[ind_max]['pseudo'], '\n  Congratulations ! You have won as a bonus 5 coins !')
            list_players[ind_max]['coins'] += 5
            print('Now you have :', list_players[ind_max]['coins'], 'coins') #******
            
        else:
            x = max(liste)
            dice_players = []
            dice_ind =[] # the list of players with the biggest score
            for num in range(len(liste)): # num is the n° of a player
                if dices[num] == x: # if dices[num] is the maximum score in the list of dices
                    dice_ind.append(num)
                    dice_players.append(list_players[num]['pseudo'])
            print('\nThe players who got the biggest score are :', dice_players, '\n  Congratulations ! You have won as a bonus 5 coins !')
            for j in dice_ind:
                list_players[j]['coins'] += 5
                print('Now you have :', list_players[j]['coins'], 'coins') #******

           

def biggest_num_obj(nb_of_players, list_players, list_objects): # ******
    """
Gives at the end each player or players who have the most objects an extra star

:param nb_of_players: (int) the number of players
:list_player: (list) list of dictionaries
:list_objects: (list) the list of number of objects of each player at the end of the game
:return: None
:effet de bord: Modifies the dictionary of one or more players by adding 1 star

:CU: nb_players >= 1 AND list_players must contain dictionaries containing the keys 'pseudo', 'stars'

"""
    if len(set(list_objects)) == nb_of_players and nb_of_players != 1:
            ind_max = list_objects.index(max(list_objects))
            print('\nThe player who got the biggest number of objects is : ', players[ind_max]['pseudo'], '\n  Congratulations ! You have won as a bonus 1 star !')
            list_players[ind_max]['stars'] += 1
            print('Now you have :', list_players[ind_max]['stars'], 'stars') #******

            
    elif len(set(list_objects)) != nb_of_players and nb_of_players != 1 :
        x = max(list_obj)
        obj_players = []
        obj_ind =[] # the list of players with the biggest number of objects
        
        for num in range(len(list_obj)): # num is the n° of a player
            if list_objects[num] == x: # if list_obj[num] is the maximum score in the list of objects
                obj_ind.append(num)
                obj_players.append(list_players[num]['pseudo'])
                
        print('\nThe players who got the biggest number of objects are :', obj_players, '\n  Congratulations ! You have won as a bonus 1 star !')
        for j in obj_ind:
            list_players[j]['stars'] += 1
            print('Now you have :', list_players[j]['stars'], 'stars') #******


            
def long_distance(nb_of_players, list_players, list_dis): # ******
    """
the procedure gives the player or players who made the longest distances an extra 10 coins

:param nb_of_players: (int) the number of players
:param list_player: (list) list of dictionaries
:param list_dis: (list) the list each player's distance

:return: None
:effet de bord: Modifies the dictionary of one or more players by adding 10 coins

:CU: nb_players >= 1 AND list_players must contain dictionaries containing the keys 'pseudo', 'coins'
"""
    if len(set(list_dis)) == nb_of_players and nb_of_players != 1:
            ind_max = list_dis.index(max(list_dis))
            print('\nThe player who got the longest distance : ', list_players[ind_max]['pseudo'], '\n  Congratulations ! You have won as a bonus 10 coins !')
            list_players[ind_max]['coins']+= 10
            print('Now you have :', list_players[ind_max]['coins'], 'coins') #******

            
    elif len(set(list_distance)) != nb_players and nb_players != 1:
        x = max(list_dis)
        dis_players = []
        dis_ind =[] # the list of players with the longest distances
        
        for num in range(len(list_dis)): # num is the n° of a player
            if list_dis[num] == x: # if list_distance[num] is the maximum score in the list of distances
                dis_ind.append(num)
                dis_players.append(list_players[num]['pseudo'])
                
        print('\nThe players who got the longest distances  are :', dis_players, '\n  Congratulations ! You have won as a bonus 10 coins !') # not pretty display ******** ???
        
        for j in dis_ind:
            list_players[j]['coins'] += 10
            print('Now you have :', list_players[j]['coins'], 'coins') #******


    
def results (nb_of_players, list_players):
    """
Prints the winner or winners of the game !
The winner is the player with the biggest number of stars.
If two or more players have same numberof stars, then we compare the numer of coins.

:param nb_of_players: (int) the number of players
:param list_player: (list) list of dictionaries
:return: None

:CU: list_players must contains dictionaries, and each dictionary must contain the keys 'stars', 'coins', 'pseudo' AND nb_players >= 1

"""
    max_stars = 0
    max_coins = 0
    first_place_stars = list()
    first_place_coins = list() # si pb ex-aequo thus LIST

    # 1/ Classement STARS

    for nb_of_player in range(nb_of_players):
        joueur = list_players[nb_of_player]

        if joueur['stars'] > max_stars:
            max_stars = joueur['stars']
            first_place_stars = [(joueur['pseudo'], nb_of_player)] # a tuple with the pseudo and the position in the list of players  
        
        elif joueur['stars'] == max_stars:
            first_place_stars.append((joueur['pseudo'], nb_of_player))
        
# if no 'ex-aequo' :

    if len(first_place_stars) == 1: # only one winner / one tuple
        pseudo_winner = [first_place_stars[0][0]] # pseudo of the winner who has the most stars
    
    else: # we compare the COINS
        for player in first_place_stars: # player == tuple('pseudo', n° dans la liste players)
            nb_of_player = player[1] # position in the list of players
            joueur = list_players[nb_of_player]

            if joueur['coins'] > max_coins:
                max_coins = joueur['coins']
                first_place_coins = [joueur['pseudo']] # a list !!
        
            elif joueur['coins'] == max_coins:
                first_place_coins.append(joueur['pseudo'])
        pseudo_winner = first_place_coins
    
# we get at the end, one or more winners !

    # 3/ Annonce du gagnant // The Winner is ! :

    if len(pseudo_winner) == 1: # just one winner //  a list if one element!
        print('\nThe game has ended ! And the WINNER is :\n\n', pseudo_winner[0].upper())

    else:
        print('\nThe game has ended ! And the WINNERS are :\n\n')
        for winner in pseudo_winner:
            print(winner.upper(), end='\t') # changer l'affichage avec un 'AND' ?? à voir ??
            print('\n\n')

    print('\n\nThanks for playing !')


def statistics_file(players):
    """
The is a procedure that creates a .csv file containing the statistics of the game that was played.
:param players: (list) The list of players depending on the game played
:return: None
:effet de bord: Creates a .csv file

:CU: the parameter players needs to be a list of dictionaries, each containing the keys 'pseudo'
'distance', 'stars', 'coins", 'objects'

"""
    SEPARATEUR = ' | '
    with open('statistics_game.csv', 'w') as sortie:
        sortie.write('Player' + SEPARATEUR + 'Total distance' + SEPARATEUR + 'Total number of stars' + SEPARATEUR + 'Total number of coins' + SEPARATEUR + 'Total number of objects' + '\n')

        for player in players:
            pseudo = player['pseudo']
            distance = str(player['distance']) # nombre de cases parcourues OK
            stars = str(player['stars'])
            coins = str(player['coins'])
            nb_objects = str(len(player['objects']))

            sortie.write(pseudo + SEPARATEUR + distance + SEPARATEUR + stars + SEPARATEUR + coins + SEPARATEUR + nb_objects + '\n')
    
    
# ----------------------------------------------------------------------------------------------------------------------------------------------------------------


    # II/ Rules of the game
    
    # 1/ Before starting the game :

nb_players = 0
while not(nb_players >= 1 and nb_players <= 4):
    try: nb_players = int(input('\nThis game can be played by 1 to 4 players only !\nPlease enter the total number of players for this game : '))

    except ValueError:
        print('\nPlease enter an integer number for the total number of players !', end='\n')

players_in_game(nb_players, players) # we call the procedure players_in_game 

nb_rounds = 0
while not(nb_rounds >= 1): # at least once per player !
    try: nb_rounds = int(input('\nGive the number of rounds you would like to play : '))
    except ValueError:
        print('\nPlease enter an integer number for the number of rounds you want to play!', end='\n')


# 2/ At the beginning of the game

cree_plateau(plateau) # To make the boardgame appear

# All players are on the 1st square of the boardgame
cree_perso(players, plateau)

 
# ind is : 1 <= ind <= len(plateau) - 1
place_etoile(ind, plateau) # initially the star is not on the first square like all the players



# 3/ Objets / If only one player or more
'''
steals +5 coins from a chosen opponent ; Banana
steals one star from a chosen opponent ; Steel Glove
adds +3 to your own dice ; Golden Mushroom
removes -3 to an opponent's dice ; Mushroom

'''

if nb_players == 1:
    list_objects = ['Golden Mushroom'] # only this object can be used when we have only ONE PLAYER

else:
    list_objects = ['Banana', 'Steel Glove', 'Golden Mushroom', 'Mushroom']


# 4/ A round of the game!!

dices = list() 
for tour in range(nb_rounds):
    dices = list() 
    print('\nThis is round n°', tour + 1)
    
    if tour == nb_rounds - 1:
        print('\nThis is the last round !')
        
    for nb_player in range(nb_players):
        gameplay(nb_player, players)
        
    end_round_dice(nb_players, players, dices)


list_obj = []
list_distance = []

for pseudo in range(len(players)): # the ones who have the max of objects  gets an extra star and the ones who have the max of distances get an extra 10 coins
    list_obj.append(len(players[pseudo]['objects']))
    list_distance.append(int(players[pseudo]['distance']))
    
biggest_num_obj(nb_players, players, list_obj)
long_distance(nb_players, players, list_distance)
results(nb_players, players)
statistics_file(players)
